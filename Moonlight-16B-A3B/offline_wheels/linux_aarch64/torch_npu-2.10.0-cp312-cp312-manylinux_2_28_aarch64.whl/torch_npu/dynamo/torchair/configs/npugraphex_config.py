__all__ = []

from typing import Callable


class _NpuGraphExConfig:
    force_eager: bool = False
    use_graph_pool = None
    reuse_graph_pool_in_same_fx: bool = True
    capture_limit: int = 64
    clone_input: bool = True
    clone_output: bool = False
    static_kernel_compile: bool = False
    super_kernel_optimize: bool = False
    super_kernel_optimize_options: dict = None
    super_kernel_debug_options: dict = None
    frozen_parameter: bool = False
    remove_noop_ops: bool = True
    remove_cat_ops: bool = True
    inplace_pass: bool = True
    input_inplace_pass: bool = True
    pattern_fusion_pass: bool = True
    post_grad_custom_pre_pass: Callable = None
    post_grad_custom_post_pass: Callable = None
    dump_tensor_data: bool = False
    data_dump_stage: str = "optimized"
    data_dump_dir: str = "./"
    _vllm_aclnn_static_kernel_sym_index: int = 0
    _vllm_aclnn_static_kernel_sym_range: list = None

    """
    Config for NpuGraphEx option
    """
    OPTIONS_TO_CONFIG_MAP = {
        "_vllm_aclnn_static_kernel_sym_index": "experimental_config.aclgraph._aclnn_static_shape_kernel_sym_index",
        "_vllm_aclnn_static_kernel_sym_range": "experimental_config.aclgraph._aclnn_static_shape_kernel_sym_value_range",
        "static_kernel_compile": "experimental_config.aclgraph._aclnn_static_shape_kernel",
        "super_kernel_optimize": "experimental_config.aclgraph._super_kernel_optimize",
        "super_kernel_optimize_options": "experimental_config.aclgraph._super_kernel_optimize_options",
        "super_kernel_debug_options": "experimental_config.aclgraph._super_kernel_debug_options",
        "inplace_pass": "debug.aclgraph.disable_reinplace_inplaceable_ops_pass",
        "input_inplace_pass": "debug.aclgraph.disable_reinplace_input_mutated_ops_pass",
        "remove_noop_ops": "experimental_config.remove_noop_ops",
        "remove_cat_ops": "debug.aclgraph.remove_cat_ops",
        "force_eager": "debug.run_eagerly",
        "pattern_fusion_pass": "experimental_config.pattern_fusion_pass",
        "clone_input": "debug.aclgraph.clone_input",
        "frozen_parameter": "experimental_config.frozen_parameter",
        "post_grad_custom_pre_pass": "post_grad_custom_pre_pass",
        "post_grad_custom_post_pass": "post_grad_custom_post_pass",
        "use_graph_pool": "aclgraph_config.use_custom_pool",
        "reuse_graph_pool_in_same_fx": "debug.aclgraph.disable_mempool_reuse_in_same_fx",
        "capture_limit": "debug.aclgraph.static_capture_size_limit",
        "clone_output": "debug.aclgraph.enable_output_clone",
        "dump_tensor_data": "dump_config.enable_dump",
        "data_dump_stage": "dump_config.data_dump_stage",
        "data_dump_dir": "dump_config.dump_path",
        
        # More mapping relationships can be extended here
    }

    @staticmethod
    def invert_bool(x):
        if isinstance(x, bool):
            return not x
        if isinstance(x, int) and x in (0, 1):
            return 1 if x == 0 else 0
        return x

    OPTIONS_TO_CONFIG_TRANSFORMATIONS = {
        "inplace_pass": invert_bool.__func__,
        "input_inplace_pass": invert_bool.__func__,
        "reuse_graph_pool_in_same_fx": invert_bool.__func__,
    }
    ALLOWED_OPTIONS = set(OPTIONS_TO_CONFIG_MAP.keys())

    def __init__(self) -> None:
        super(_NpuGraphExConfig, self).__init__()

    @classmethod
    def as_dict(cls):
        options = {}
        for k, v in cls.__dict__.items():
            if k in cls.OPTIONS_TO_CONFIG_MAP:
                options[k] = v
        return options
        

def _process_kwargs_options(config, kwargs):
    """
    Processes the "options" parameter to config.

    Args:
        config: Configuration object to be updated with valid option settings
        kwargs: Parameter dictionary that may contain the "options" entry to be processed

    Raises:
        ValueError: Triggered when the "options" entry contains identifiers not specified 
                    in the predefined mapping rules
    """
    
    # Process target parameter
    if "options" in kwargs:
        options = kwargs["options"]
        for option in options:
            if option not in _NpuGraphExConfig.ALLOWED_OPTIONS:
                raise ValueError(f"Invalid option '{option}', allowed options: {sorted(_NpuGraphExConfig.ALLOWED_OPTIONS)}")

            option_value = options[option]
            setattr(_NpuGraphExConfig, option, option_value)
            if option in _NpuGraphExConfig.OPTIONS_TO_CONFIG_TRANSFORMATIONS:
                transform_func = _NpuGraphExConfig.OPTIONS_TO_CONFIG_TRANSFORMATIONS[option]
                processed_value = transform_func(option_value)
            else:
                processed_value = option_value

            # Parse option and assign config value
            current = config
            parts = _NpuGraphExConfig.OPTIONS_TO_CONFIG_MAP[option].split(".")
            for part in parts[:-1]:
                current = getattr(current, part)
            setattr(current, parts[-1], processed_value)