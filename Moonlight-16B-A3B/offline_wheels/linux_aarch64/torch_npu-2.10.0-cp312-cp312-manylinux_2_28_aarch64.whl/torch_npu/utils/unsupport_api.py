import torch

"""
key: attr_name(str)
value: parent_module(object)
"""

unsupported_Tensor_api = {
}

unsupported_nn_api = {
    "share_memory": torch.nn.Module,
    "add_module": torch.jit.ScriptModule,
    "bfloat16": torch.jit.ScriptModule,
    "register_buffer": torch.jit.ScriptModule,
    "register_parameter": torch.jit.ScriptModule,
    "register_module": torch.jit.ScriptModule
}
