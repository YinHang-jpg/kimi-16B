def constexpr():
    pass