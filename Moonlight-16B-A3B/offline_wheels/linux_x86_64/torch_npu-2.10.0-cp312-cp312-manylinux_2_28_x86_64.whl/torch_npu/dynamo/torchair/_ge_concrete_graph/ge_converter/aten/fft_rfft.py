from torchair._ge_concrete_graph.ge_converter.converter_utils import *


@register_fx_node_ge_converter(torch.ops.aten.fft_rfft.default)
def conveter_aten_fft_rfft_default(
    self: Tensor,
    n: Optional[Union[int, Tensor]] = None,
    dim: int = -1,
    norm: Optional[str] = None,
    meta_outputs: TensorSpec = None,
):
    """NB: aten::fft_rfft(Tensor self, SymInt? n=None, int dim=-1, str? norm=None) -> Tensor"""
    raise NotImplementedError("torch.ops.aten.fft_rfft.default ge_converter is not implemented!")


@register_fx_node_ge_converter(torch.ops.aten.fft_rfft.out)
def conveter_aten_fft_rfft_out(
    self: Tensor,
    n: Optional[Union[int, Tensor]] = None,
    dim: int = -1,
    norm: Optional[str] = None,
    *,
    out: Tensor = None,
    meta_outputs: TensorSpec = None
):
    """NB: aten::fft_rfft.out(Tensor self, SymInt? n=None, int dim=-1, str? norm=None, *, Tensor(a!) out) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.fft_rfft.out ge_converter is not implemented!")
